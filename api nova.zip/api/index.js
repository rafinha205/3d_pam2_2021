const express = require('express')
const servidor = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    user: 'root',
    password: 'minas',
    database: '3d_2021',
    host: 'localhost',
    port: '3306',
})

servidor.get('/testaeconexao', (req, res, next) => {
    banco.getConnection(
        (error, conn) => {
            if(error){
                return res.status(500).send({
                    mensagem : "Erro no servidor",
                    detalhes: error
                })
            }
            conn.release()
            
        }

        

        )
})

servidor.get('/', (req, res, next) => {
    return res.status(200).send({
        mensagem: 'Servidor funcionando!'
    })
})

servidor.listen(3000, () => {
    console.log('Servidor funcionando')
})

